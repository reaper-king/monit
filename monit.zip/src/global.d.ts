/// <reference types="@sveltejs/kit" />
interface ImportMetaEnv {
    VITE_SENDGRID_API_KEY: string;
}