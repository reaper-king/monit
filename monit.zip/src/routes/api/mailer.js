import { renderMail } from 'svelte-mail';
// import Mail from 'src/routes/components/Mail.svelte';

import Mail from "../components/Mail.svelte";
import sgMail from '@sendgrid/mail';


let sender;
let receiver;
let subject;
let api_fs_data
let server;

sgMail.setApiKey(
    import.meta.env.VITE_SENDGRID_API_KEY)



export function post(request) {
    const object = {};
    for (const [key, value] of request.body.entries()) {
        object[key] = value;
    }
    sender = object.sender || 'marcques.ethanmouton@npesnam.com'
    receiver = object.receiver || 'marcques.ethanmouton@stor-systems.com'
    subject = object.subject || 'Server Monitor | Filesystem'
    server = object.server
    api_fs_data = JSON.parse(object.data)
        // console.log(object)

    sendMail()

    // console.log(JSON.parse(object.data))
    // console.log(request.url.searchParams)

    return {

        status: 202
            // body: { object }
    }




}



async function sendMail() {
    const { html, text } = await renderMail(Mail, { data: { server: server, fs_data: api_fs_data.discarray } });



    const msg = {
        to: receiver,
        from: sender,
        subject: subject,
        text: text,
        html: html,
    }



    sgMail
        .send(msg)
        .then(() => {
            console.log('Email sent')
        })
        .catch((error) => {
            console.error(error)
        })
}