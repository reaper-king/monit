<script>

  // console.log(import.meta.env.VITE_SENDGRID_API_KEY)
 import Mail from './components/Mail.svelte'

</script>
<Mail/>