<script>

export let server = 'cs server' ;
export let fs_data = [
    {
        "fs": "udev",
        "mount": "/dev",
        "size": "459M",
        "used": "0",
        "avail": "459M",
        "use_perc": "0%"
    },
    {
        "fs": "tmpfs",
        "mount": "/run",
        "size": "98M",
        "used": "1.2M",
        "avail": "97M",
        "use_perc": "2%"
    },
    {
        "fs": "/dev/sda1",
        "mount": "/",
        "size": "45G",
        "used": "6.5G",
        "avail": "39G",
        "use_perc": "15%"
    },
    {
        "fs": "tmpfs",
        "mount": "/dev/shm",
        "size": "487M",
        "used": "0",
        "avail": "487M",
        "use_perc": "0%"
    },
    {
        "fs": "tmpfs",
        "mount": "/run/lock",
        "size": "5.0M",
        "used": "0",
        "avail": "5.0M",
        "use_perc": "0%"
    },
    {
        "fs": "tmpfs",
        "mount": "/sys/fs/cgroup",
        "size": "487M",
        "used": "0",
        "avail": "487M",
        "use_perc": "0%"
    },
    {
        "fs": "/dev/loop2",
        "mount": "/snap/lxd/21835",
        "size": "68M",
        "used": "68M",
        "avail": "0",
        "use_perc": "100%"
    },
    {
        "fs": "/dev/loop1",
        "mount": "/snap/core20/1242",
        "size": "62M",
        "used": "62M",
        "avail": "0",
        "use_perc": "100%"
    },
    {
        "fs": "/dev/loop0",
        "mount": "/snap/core18/2253",
        "size": "56M",
        "used": "56M",
        "avail": "0",
        "use_perc": "100%"
    },
    {
        "fs": "/dev/loop3",
        "mount": "/snap/oracle-cloud-agent/26",
        "size": "59M",
        "used": "59M",
        "avail": "0",
        "use_perc": "100%"
    },
    {
        "fs": "/dev/loop4",
        "mount": "/snap/snapd/14066",
        "size": "43M",
        "used": "43M",
        "avail": "0",
        "use_perc": "100%"
    },
    {
        "fs": "/dev/sda15",
        "mount": "/boot/efi",
        "size": "105M",
        "used": "5.2M",
        "avail": "100M",
        "use_perc": "5%"
    },
    {
        "fs": "tmpfs",
        "mount": "/run/user/1001",
        "size": "98M",
        "used": "0",
        "avail": "98M",
        "use_perc": "0%"
    },
    {
        "fs": "/dev/loop5",
        "mount": "/snap/core20/1270",
        "size": "62M",
        "used": "62M",
        "avail": "0",
        "use_perc": "100%"
    },
    {
        "fs": "/dev/loop6",
        "mount": "/snap/snapd/14295",
        "size": "44M",
        "used": "44M",
        "avail": "0",
        "use_perc": "100%"
    },
    {
        "fs": "/dev/loop7",
        "mount": "/snap/oracle-cloud-agent/28",
        "size": "59M",
        "used": "59M",
        "avail": "0",
        "use_perc": "100%"
    },
    {
        "fs": "/dev/loop8",
        "mount": "/snap/core18/2284",
        "size": "56M",
        "used": "56M",
        "avail": "0",
        "use_perc": "100%"
    }
]
 const   year = new Date().getFullYear()
</script>

<div marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0">
    <!--100% body table-->
    <table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8"
        style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: 'Open Sans', sans-serif;">
        <tr>
            <td>
                <table style="background-color: #f2f3f8; max-width:670px;  margin:0 auto;" width="100%" border="0"
                    align="center" cellpadding="0" cellspacing="0">
                    <tr>
                        <td style="height:80px;">&nbsp;</td>
                    </tr>
                    <tr>
                        <td style="text-align:center;">
                          <a href="https://www.stor-systems.com/" title="logo" target="_blank">
                            <img width="200" src="http://cdn.mcauto-images-production.sendgrid.net/730cb00c41d13524/b5d947c7-a42c-4099-a4d0-962c228059f7/3203x1011.png" title="logo" alt="logo">
                          </a>
                        </td>
                    </tr>
                    <tr>
                        <td style="height:20px;">&nbsp;</td>
                    </tr>
                    <tr>
                        <td>
                            <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0"
                                style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);">
                                <tr>
                                    <td style="height:40px;">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="padding:0 35px;">
                                        <h1 style="color:#1e1e2d; font-weight:500; margin:0;font-size:32px;font-family:'Rubik',sans-serif;">{server}</h1>
                                                          </td>
                                </tr>
                                <tr>
                                    <td width="92%" style="padding: 4%;">
                                                    <table cellspacing="0" cellpadding="0" border="0" width="100%">
                                                        <tr>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; font-weight: bold; border-bottom: 1px solid #cccccc" class="data-table-th">
                                                                Filesystem
                                                            </td>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; font-weight: bold; border-bottom: 1px solid #cccccc" class="data-table-th">
                                                                Size
                                                            </td>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; font-weight: bold; border-bottom: 1px solid #cccccc" class="data-table-th">
                                                                Used
                                                            </td>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; font-weight: bold; border-bottom: 1px solid #cccccc" class="data-table-th">
                                                                Available
                                                            </td>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; font-weight: bold; border-bottom: 1px solid #cccccc" class="data-table-th">
                                                                Used %
                                                            </td>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; font-weight: bold; border-bottom: 1px solid #cccccc" class="data-table-th">
                                                                Mounted On
                                                            </td>
                                                        </tr>
                                                        {#each fs_data as item}
                                                        <tr>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; border-bottom: 1px solid #eeeeee" class="data-table-td-title">
                                                                {item.fs}
                                                            </td>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; border-bottom: 1px solid #eeeeee" class="data-table-td">
                                                                {item.size}
                                                            </td>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; border-bottom: 1px solid #eeeeee" class="data-table-td">
                                                                {item.used}
                                                            </td>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; border-bottom: 1px solid #eeeeee" class="data-table-td">
                                                                {item.avail}
                                                            </td>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; border-bottom: 1px solid #eeeeee" class="data-table-td">
                                                                {item.use_perc}
                                                            </td>
                                                            <td valign="top" align="left" style="padding: 10px 0; font-family: sans-serif; font-size: 15px; line-height: 1.3; color: #333333; border-bottom: 1px solid #eeeeee" class="data-table-td">
                                                                {item.mount}
                                                            </td>
                                                            <td style="display: none;" class="data-table-mobile-divider">&nbsp;</td>
                                                        </tr>
                                                        {/each}
                                                        
                                                    </table>
                                    </td>
                                  </tr>
                                <tr>
                                    <td style="height:40px;">&nbsp;</td>
                                </tr>
                            </table>
                        </td>
                    <tr>
                        <td style="height:20px;">&nbsp;</td>
                    </tr>
                    <tr>
                        <td style="text-align:center;">
                            <p style="font-size:14px; color:rgba(69, 80, 86, 0.7411764705882353); line-height:18px; margin:0 0 0;">&copy; <strong>Copyright  {year} | All Rights Reserved | Stor-Systems Ltd.</strong></p>
                        </td>
                    </tr>
                    <tr>
                        <td style="height:80px;">&nbsp;</td>
                       
                    </tr>
                     
                </table>
            </td>
        </tr>
    </table>
    <!--/100% body table-->
</div>
